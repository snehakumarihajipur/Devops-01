from django.test import TestCase

# Create your tests here.

class test_class():
    pass
